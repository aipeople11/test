# Humanity AI Circle V2 — Independent Deep Research and Recommended Vision for V3

As of **September 26, 2026**, the research strongly supports V2's diagnosis but points to a more defensible category than “AI community”: a **community-powered real-world AI evidence network**. AI use at work is already mainstream—58% of employees globally report semi-regular or regular workplace AI use, while 52% say AI products make them nervous; India combines >80% workplace usage with the sharpest year-over-year rise in nervousness, +14 percentage points. citeturn18search0 At the enterprise level, adoption is far ahead of proof: McKinsey reports 88% of organizations using AI in at least one function but only 7% fully scaled, while Thomson Reuters finds only 18% of professional-services respondents say their organizations track AI ROI. citeturn14search15turn18search4 Most importantly, controlled studies show that AI outcomes are **task-, user-, context-, model- and time-dependent**—which means Humanity AI Circle's long-term asset should not be reviews or membership count, but **versioned, replicated evidence of what works, for whom, under what conditions**. citeturn19search2turn22search5turn22search0

## Research findings

**1) Top research findings with the strongest data points**

The major finding is not simply “AI adoption is high.” It is that **adoption is high while reliable outcome measurement remains weak**. That gap is the best strategic justification for Humanity AI Circle.

| Finding | Strongest current evidence | Strategic implication |
|---|---|---|
| **Workplace AI has crossed into the mainstream globally** | Stanford's 2026 AI Index reports **58% of employees globally** use AI at work semi-regularly or regularly. Workplace use exceeds **80% in India, China, Nigeria, UAE, Egypt and Saudi Arabia**. citeturn18search0 | Do not build primarily around “introducing people to AI.” Build around helping existing users become better and safer at applying it. |
| **Adoption and anxiety are rising together** | Globally, 59% say AI offers more benefits than drawbacks, but **52% say AI makes them nervous**. India recorded the largest 2024–25 increase in nervousness at **+14 percentage points**, versus only +2 points in excitement. citeturn18search0 | V2's emotional thesis is valid, especially in India: users do not only need tutorials; they need confidence based on evidence. |
| **Organizational adoption is broad, but scaling is shallow** | McKinsey's 2025 global survey found **88%** of respondents said their organization uses AI in at least one function and **79%** reported GenAI use, yet only **7%** said AI had been fully scaled across the organization. citeturn13search6turn14search15 | The opportunity is increasingly about moving from experimentation to repeatable workflows, not tool discovery. |
| **ROI measurement is a major missing layer** | Thomson Reuters' 2026 professional-services study says only **18%** know their organization tracks AI ROI; another **40% do not know whether it is measured**. Organization-wide AI use had meanwhile risen to 40%, from 22% in 2025. citeturn18search4turn18search5 | “Did this produce value?” can become a core product question. |
| **Individuals are often ahead of their organizations** | Among 1,816 professionals surveyed by Thomson Reuters, **74% use AI several times per week**, 44% multiple times daily, **41% lack access to professional-grade AI**, and **34% admit using unsanctioned AI**. Where a named AI strategy exists, 66% say AI meets or exceeds value expectations versus 22% where no active strategy exists. citeturn18search1 | There is space for trusted peer learning, but governance/context must be part of evidence—not an afterthought. |
| **AI can produce large real gains—but only on the right task** | A preregistered Science RCT with **453 professionals** found ChatGPT reduced completion time on bounded professional writing tasks by **40%** and raised measured quality by **18%**. Exposed workers were twice as likely to report using ChatGPT at work two weeks later. citeturn19search2 | Outcome evidence should be task-specific. “ChatGPT increases productivity” is too broad; “workflow X on task Y under conditions Z” is appropriate. |
| **The same broad technology can hurt performance on other work** | The “Jagged Technological Frontier” experiment with **758 BCG consultants** found AI users completed 12.2% more in-frontier tasks and did them 25.1% faster, with higher quality, while on a deliberately out-of-frontier task AI users were **19 percentage points less likely to get the correct answer**. citeturn19search15 | V2's “what worked?” concept should evolve to “where does it work, where does it break, and how reliably?” |
| **Users can badly misjudge whether AI helped them** | METR's randomized study of experienced open-source developers found early-2025 AI tools made them **19% slower** on their own repository tasks. Before working, developers expected AI to make them 24% faster; even afterward, they believed it had made them 20% faster. citeturn22search5 | Self-reported reviews alone are inadequate. Wherever practical, collect baselines, timestamps, output evidence and objective outcome measures. |
| **Repeatability itself is an unsolved problem** | Artificial Analysis' August 2026 AA-AnalystAgent benchmark ran **80 real-world quantitative questions across five attempts each**; even the best model answered only **54% correctly on all five attempts**. citeturn15search15 | V3 should treat repeated success—not one impressive run—as the key evidence primitive. |
| **Evidence expires quickly as AI changes** | METR's 2026 follow-up believes developers are probably more accelerated by newer AI than in early 2025, but adoption created severe selection effects: many developers no longer wanted to participate if AI might be prohibited. The later estimates were therefore described as weak evidence. citeturn22search0 | Every evidence claim needs model/version/date and a freshness policy. A review from six months ago can be obsolete. |

The labor-market context strengthens this opportunity. The ILO estimates **one in four workers worldwide** is in an occupation with some GenAI exposure, while 3.3% of global employment is in its highest-exposure category; exposure reaches 34% in high-income economies. citeturn17search0turn17search9 PwC's 2026 analysis of more than one billion job advertisements finds AI-specific job postings grew **69% versus 9% for the overall job market**, the estimated wage premium for AI skills reached **62%**, and highly AI-exposed entry-level jobs are seven times more likely to ask for capabilities traditionally associated with senior workers, such as judgment and leadership. citeturn21search0turn21search3

That last point is especially important for the “humanity” part of the brand. Thomson Reuters found **48% of professionals worry about the effect of AI on developing independent judgment**, while PwC finds AI-exposed work is placing greater emphasis on human judgment, creativity and leadership rather than making these attributes irrelevant. citeturn18search1turn21search0

OpenAI's own enterprise telemetry—useful but necessarily vendor-specific—points in the same direction: more than one million business customers, more than seven million workplace seats, 19× year-to-date growth in weekly users of structured Projects/Custom GPT workflows, and 75% of surveyed enterprise workers reporting improvement to speed or quality. citeturn13search0turn13search1 This should be treated as adoption evidence rather than independent proof of causal ROI.

**Priority primary-source stack for V3 claims**

| Priority | Source and URL | Best use |
|---|---|---|
| **P0** | [Stanford HAI — 2026 AI Index, Public Opinion](https://hai.stanford.edu/ai-index/2026-ai-index-report/public-opinion) citeturn18search0 | Global adoption, attitudes, nervousness, India |
| **P0** | [Thomson Reuters — Future of Professionals 2026](https://www.thomsonreuters.com/en/institute/future-of-professionals-2026/report) citeturn18search1 | Professional usage, shadow AI, strategy, judgment |
| **P0** | [Thomson Reuters — AI in Professional Services 2026](https://www.thomsonreuters.com/en/reports/2026-ai-in-professional-services-report) citeturn18search4 | AI ROI-measurement gap |
| **P0** | [ILO — Generative AI and Jobs: Refined Global Index](https://www.ilo.org/publications/generative-ai-and-jobs-refined-global-index-occupational-exposure) citeturn17search0 | Global labor exposure |
| **P0** | [Noy & Zhang, Science — Experimental Evidence on Productivity](https://doi.org/10.1126/science.adh2586) citeturn19search2 | Causal productivity evidence |
| **P0** | [METR — Experienced Developer Productivity RCT](https://metr.org/blog/2025-07-10-early-2025-ai-experienced-os-dev-study/) citeturn22search5 | Negative result, perceived vs measured value |
| **P0** | [METR — 2026 Uplift Experiment Update](https://metr.org/blog/2026-02-24-uplift-update/) citeturn22search0 | Evidence decay and measurement difficulty |
| **P1** | [PwC — 2026 Global AI Jobs Barometer](https://www.pwc.com/gx/en/1/services/ai/ai-jobs-barometer.html) citeturn21search3 | Jobs, skills, productivity, wage signals |
| **P1** | [McKinsey — AI at Work but Not at Scale](https://www.mckinsey.com/featured-insights/charts/ai-at-work-but-not-at-scale) citeturn13search6 | Enterprise adoption/scaling gap |
| **P1** | [Artificial Analysis — AA-AnalystAgent](https://artificialanalysis.ai/articles/aa-analyst-agent) citeturn15search15 | Repeatability/reliability |
| **P1** | [LMArena](https://lmarena.ai/) citeturn16search3turn16search5 | Proof that large-scale community evaluation can work |
| **P2** | [OpenAI — State of Enterprise AI 2025](https://openai.com/business/guides-and-resources/the-state-of-enterprise-ai-2025-report/) citeturn13search0 | Vendor-specific real-world usage patterns |

## What the evidence validates

**2) What research validates in Humanity AI Circle V2**

The central intellectual foundation of V2 is strong. V2 says that **“information is abundant; evidence is scarce”**, proposes outcome-first discovery, defines evidence around WHO → WHAT → TASK → TOOL → CONTEXT → RESULT → VERDICT, and argues that the long-term asset should be an evidence graph connecting people, professions, problems, tasks, tools, workflows and outcomes. fileciteturn0file0 The independent evidence supports those ideas more strongly than it supports the generic “AI community” framing.

| V2 thesis | Research verdict | Why |
|---|---|---|
| **“Too much information, too little trusted evidence”** | **Strongly validated** | High adoption coexists with weak ROI tracking and shallow scaling. citeturn18search4turn13search6 |
| **Outcome first, not tool first** | **Strongly validated** | Controlled research shows the same technology can materially help one task and hurt another. citeturn19search2turn19search15turn22search5 |
| **Context matters** | **Strongly validated** | Effects vary with task, skill level, workflow, model capability and professional context. citeturn19search2turn19search15 |
| **Human judgment remains important** | **Strongly validated** | Professional judgment concerns are substantial, while labor-market demand is shifting toward judgment, leadership and other senior human capabilities. citeturn18search1turn21search0 |
| **Structured evidence beats star ratings** | **Strongly validated** | A generic score cannot represent task-specific upside, failure boundaries or run-to-run reliability. citeturn15search15turn22search5 |
| **Community can produce useful evaluation data** | **Validated, with qualification** | LMArena demonstrates that community-generated human preference data can reach millions of votes and power useful public leaderboards. citeturn16search3turn16search5 |
| **Trust first, data second** | **Strongly validated** | Shadow AI and governance gaps make transparency, privacy and provenance important product requirements. citeturn18search1 |
| **Build a compounding evidence graph** | **Strategically validated** | The observed heterogeneity means long-term value lies in accumulating relationships between task, context, workflow, model/version, outcome and human validation—not merely accumulating tool pages. citeturn19search15turn22search0 |

V2's best existing sentence is therefore not its broad community definition. It is effectively:

> **Tool X worked for Task Y, for User Type Z, under Conditions A/B/C, with these strengths, limitations and human checks.** fileciteturn0file0

I would preserve that idea and make it more rigorous:

> **Workflow X produced Outcome Δ for Task Y, versus Baseline B, for User/Context Z, using Model Version M, across N independent attempts, with R% repeatability and these human-review requirements.**

That moves Humanity AI Circle from **opinion** toward **evidence**.

V2 also correctly avoids generic 4.7/5 ratings. The research shows why that matters: Artificial Analysis can find a model performing correctly once but failing to reproduce that correctness across five attempts, while real-world human experiments can produce opposite productivity effects across tasks. citeturn15search15turn22search5 Averages without context hide the very thing users need to know.

## What needs to change

**3) What the research disproves or materially weakens**

The evidence does **not** disprove the need for Humanity AI Circle. It does disprove several assumptions about where the moat lies.

**First, “community-validated AI outcomes” is no longer an empty category.** LMArena already operates community-led model evaluation at substantial scale; Artificial Analysis runs rigorous independent benchmarks and in August 2026 launched Optima for building custom benchmarks from customers' own tasks/files; Workhelix explicitly sells enterprise visibility into AI ROI; GetPrompting tests tools against real workflows; and ClawReviews is explicitly building a reputation layer around specific experiences with AI products. citeturn16search3turn15search16turn15search7turn15search1turn16search2

Therefore this V2 statement is too broad as a moat:

> **Humanity AI Circle should own community-validated outcomes.** fileciteturn0file0

The defensible version is closer to:

> **Humanity AI Circle should own contextual, repeatable, human-validated evidence about real AI-assisted work.**

**Second, community itself is not the moat.** Product Hunt already has a community-driven product discovery model, G2 has surpassed three million reviews and 200,000 products/services while reaching more than 100 million buyers through its ecosystem, and LMArena has established massive community evaluation behavior. citeturn14search9turn14search16turn16search3 The moat has to be a **data and methodology advantage** that competitors do not naturally collect: baselines, workflow context, outcome metrics, failures, human correction, independent replications and longitudinal/version history.

**Third, self-reported “what worked for me” is not sufficient evidence.** METR is the strongest warning. Developers expected large gains and continued believing AI had helped after the randomized measurement showed a slowdown. citeturn22search5 V2 should distinguish **experience/testimony** from **measured evidence** rather than placing both in one bucket.

A useful hierarchy would be:

```text
ANECDOTE
"I liked it."
        ↓
OBSERVED EXPERIENCE
"I used it for this task and here is what happened."
        ↓
MEASURED RUN
"Here is the baseline, workflow and measured outcome."
        ↓
VERIFIED RUN
"Another person/expert checked the evidence."
        ↓
INDEPENDENT REPLICATION
"Other users repeated the same task protocol."
        ↓
REPLICATED EVIDENCE CLAIM
"We know the success distribution, conditions and uncertainty."
```

**Fourth, a static evidence card will age badly.** METR's early-2025 finding and its February 2026 follow-up illustrate how quickly the relationship between AI capability and real work can change—and even how measurement methods can break as users become dependent on AI. citeturn22search0turn22search5 Model/version, workflow version and `tested_at` should therefore be mandatory fields.

**Fifth, “build the community first, then let it generate evidence” is too risky as product sequencing.** It can easily produce another active WhatsApp/Discord/Slack community containing conversations but little defensible data. The stronger sequence is:

```text
DEFINE A REAL TASK
        ↓
CREATE A TEST PROTOCOL
        ↓
RECRUIT PEOPLE TO RUN IT
        ↓
COMPARE OUTCOMES
        ↓
DISCUSS FAILURES
        ↓
REPLICATE
        ↓
BUILD COMMUNITY AROUND
USEFUL EVIDENCE
```

This is a strategic inference from the research rather than a directly measured finding, but it follows from the large gap between broad AI adoption and measurable/scaled outcomes. citeturn18search4turn13search6

**Sixth, V2 is too broad at launch.** Students, job seekers, founders, builders, professionals, mentors, senior executives, schools, cities, finance, HR, legal and small businesses all produce fundamentally different tasks, risk levels and definitions of success. fileciteturn0file0 The repeatability research makes this breadth even more problematic: the more contexts mixed together, the less interpretable the resulting “evidence” becomes. citeturn19search15turn15search15

## What V3 should add

**4) What is genuinely new and should be added**

The single most important new concept is:

> **Repeatability is what converts community experience into evidence.**

One person succeeding once is an experience.

Ten independent people succeeding under comparable conditions starts becoming evidence.

Repeated success across different user types allows the network to learn **for whom it works**.

Repeated failures reveal the boundary of the workflow.

This is exactly the distinction exposed by current research: one-run benchmark accuracy can materially overstate reliability, task effects differ dramatically, and results change as AI systems evolve. citeturn15search15turn19search15turn22search0

V3 should therefore introduce five new primitives.

**Evidence Protocol.** Define the task before evaluating the tool: input, desired output, success criteria, quality rubric, baseline method, permitted resources, task risk and expected human checks. This avoids retroactively defining “success.”

**Evidence Run.** Record what actually happened: participant context, workflow, model and version, prompts/instructions where shareable, time, cost, result, correction time, failure points and artifacts.

**Validation.** Record who assessed the outcome: user, independent peer, domain expert, objective ground truth or automated test. These should remain visibly different.

**Replication.** Link multiple independent runs to the same protocol. Track not only the mean but the distribution, failure rate and conditional differences between user cohorts.

**Evidence Claim.** Generate a derived, versioned claim from those runs, for example:

> “For this workflow and task protocol, 19 of 25 independent users met the defined quality threshold; median net time fell 31%, but 7/25 required source corrections. Evidence last updated September 2026.”

Do not expose a false-precision “AI Score: 8.7/10.” Display **sample size, success distribution, evidence strength, freshness and conditions**.

The evidence graph should therefore evolve from V2's current graph into this:

```mermaid
flowchart LR
    P["Person<br/>Role • Skill • Experience"] --> C["Context<br/>Industry • Stakes • Sensitivity"]
    C --> T["Task Protocol<br/>Input • Goal • Success Criteria"]

    T --> B["Baseline<br/>Current / No-AI Method"]
    T --> W["AI Workflow<br/>Tools • Model • Version • Recipe"]

    B --> D["Outcome Delta"]
    W --> D

    D --> M["Measured Result<br/>Time • Quality • Cost • Accuracy"]
    M --> H["Human Intervention<br/>Correction • Judgment • Review"]
    H --> F["Failure Modes"]
    F --> V["Validation<br/>Peer • Expert • Ground Truth"]

    V --> R["Independent Replications"]
    R --> E["Evidence Claim<br/>N • Distribution • Confidence • Freshness"]

    E --> G["Evidence Graph"]
    G --> Q["Next User Decision"]

    Q --> R
```

The **baseline** is particularly important. Productivity evidence without a counterfactual can be misleading; METR's developer study showed the gap between what users felt and what randomized measurement observed. citeturn22search5

The **model/version/date** dimension is equally important. METR's subsequent study could no longer cleanly reproduce its earlier experimental setup because actual user behavior and AI capabilities had shifted, while Artificial Analysis continuously updates benchmarks as frontier systems change. citeturn22search0turn15search17

The data model should therefore move from:

```text
WHO
WHAT
TASK
TOOL
CONTEXT
RESULT
VERDICT
```

to:

```text
PersonContext
    ↓
TaskProtocol
    ↓
Baseline
    ↓
Workflow
    ↓
Tool + Model + Version
    ↓
EvidenceRun
    ↓
OutcomeMetrics
    ↓
HumanCorrection
    ↓
FailureModes
    ↓
Validation
    ↓
ReplicationGroup
    ↓
EvidenceClaim
    ↓
Confidence + Freshness
```

Add these fields explicitly:

| Entity | Critical additions |
|---|---|
| `PersonContext` | role, function, seniority, skill level, prior AI experience, industry; geography only where useful |
| `TaskProtocol` | task class, input type, success criteria, quality rubric, risk level |
| `Baseline` | existing workflow, time, cost, quality |
| `Workflow` | exact workflow steps, AI/human handoffs |
| `ToolRun` | tool, underlying model when knowable, model/version, plan/tier, date |
| `Outcome` | completion, quality, accuracy, time, total cost, net time saved |
| `HumanIntervention` | review time, corrections, judgment required, escalation |
| `Failure` | hallucination, omission, wrong reasoning, poor formatting, tool failure, privacy/security issue, other |
| `Validation` | self, peer, domain expert, deterministic check, ground truth |
| `Replication` | protocol ID, independent tester ID, run index |
| `Provenance` | evidence artifact, affiliation, incentive/sponsorship disclosure |
| `Privacy` | consent, visibility, data sensitivity, retention policy |
| `EvidenceClaim` | sample size, outcome distribution, confidence tier, last-tested date |

This design creates a far more defensible graph than generic reviews because it captures the variables current studies show matter. citeturn19search2turn19search15turn22search5turn15search15

## What to remove or defer

**5) What should not be built yet**

V2 already warns itself to “start narrow in execution; stay broad in vision.” fileciteturn0file0 The research says this should become a hard product constraint, not merely a strategic guardrail.

| V2 idea | Recommendation now | Trigger before revisiting |
|---|---|---|
| Students / schools | **Defer** | A separately validated student outcome problem |
| Job seekers / career platform | **Defer** | Strong evidence that existing professional members need it |
| Generic founders community | **Defer** | A task cluster with measurable founder outcomes |
| Mentor marketplace | **Defer** | Recurring mentor demand visible inside evidence runs |
| Idea ↔ builder matching | **Defer** | Organic matching repeatedly occurs |
| Jobs / opportunity marketplace | **Defer** | High member density and credible identity/reputation layer |
| City circles | **Defer** | Local demand significantly changes task/context evidence |
| Finance / HR / Legal / Education circles | **Defer formal groups** | Enough evidence density to justify separate taxonomy/moderation |
| Tool directory | **Do not build as core product** | Existing marketplaces already dominate discovery |
| Prompt library | **Do not build as core product** | Prompts should live inside validated workflow evidence |
| AI news feed | **Do not build as core product** | News should trigger tests, not become the product |
| Generic 1–5 star reviews | **Avoid** | They erase context and reliability |
| Large-scale data monetization | **Defer** | Consent, governance and sufficient evidence density |
| Enterprise AI-readiness product | **Defer** | First prove evidence methodology with individuals/cohorts |
| Generic networking | **Defer** | Connect people specifically around tasks/evidence first |

The weekly 30-minute session should **remain only if it generates a measurable artifact**. Instead of:

> “This week we demonstrate Claude.”

run:

> “Twenty people test three workflows for producing a source-backed executive memo from the same research package; next week we publish what replicated.”

That turns content into data.

Similarly, keep **profession-specific discussions**, but do not create ten empty circles. Use evidence density to determine when a subcommunity deserves to exist.

## Starting wedge and competitive position

**6) Strongest starting wedge, product, KPIs, market size and competitor map**

### Recommended wedge

I would **not** begin with “all working professionals.”

I recommend:

> **English-speaking, AI-active mid-career knowledge workers in marketing, product, strategy and business operations who repeatedly turn research/data into professional deliverables.**

The product can be global from day one, while **India is an unusually attractive recruitment beachhead** because Stanford reports workplace AI use above 80% there while nervousness rose faster than in any other surveyed country. citeturn18search0

Why this wedge instead of legal/finance first? Legal, tax and compliance clearly have demand, but they introduce high verification, confidentiality and professional-liability burdens immediately; Thomson Reuters' findings demonstrate how central authoritative content, privacy and professional accountability are in those fields. citeturn18search1

Why not software engineering first? The outcomes are easier to benchmark, but that field already has exceptionally strong evaluation infrastructure—including METR, LMArena, coding benchmarks, GitHub/Copilot research and Artificial Analysis. citeturn22search5turn16search11turn15search0 The competitive whitespace is better in ordinary business knowledge work.

Marketing/product is also showing visible value in enterprise usage: OpenAI's enterprise survey reports 85% of marketing and product users saying AI accelerated campaign execution, although this is vendor self-reported data and should be treated as a directional signal rather than independent causal evidence. citeturn13search0

### Initial product

Do not launch “the Humanity AI Circle platform” with twenty community features.

Launch one primitive:

> **Outcome Tests: run a real professional task, measure the result, and compare it with independent replications.**

Start with three protocols:

| Protocol | Baseline | Core measures |
|---|---|---|
| **Research package → executive decision memo** | Human/current workflow | factual accuracy, source coverage, quality rubric, total time, correction time |
| **Research notes → source-backed presentation** | Human/current workflow | evidence fidelity, slide usefulness, source errors, time, rework |
| **Structured dataset → decision-ready analysis** | Human/current workflow | numeric correctness, missed anomalies, interpretation quality, total time |

For early cohorts, use **synthetic or explicitly consented non-sensitive materials** so privacy does not block the experiment. Once the methodology is proven, members can test their own work under stronger data-control rules.

A resulting Evidence Card should look more like:

```text
OUTCOME
Research pack → executive memo

PROTOCOL
v1.4

INDEPENDENT RUNS
38

SUCCESS THRESHOLD MET
29 / 38

MEDIAN TOTAL TIME
Baseline: 54 min
AI workflow: 31 min
Human review: 9 min included

QUALITY
Median rubric delta: +11%

FAILURES
Unsupported factual claim: 18%
Missed important source: 13%
Formatting only: 8%

EXPERIENCE EFFECT
Advanced AI users: 86% success
Early users: 63% success

WORKFLOW / MODEL
Versioned and linked

LAST TESTED
September 2026

EVIDENCE STRENGTH
Moderate
Reason: 38 independent runs,
2 expert-reviewed cohorts
```

Those figures are illustrative product UI, **not research findings**.

### Market sizing

Because no revenue model has been selected, a dollar TAM would be false precision. The most defensible sizing today is a **population/problem-space sizing**.

ILO reports 186 million unemployed people corresponding to a 4.9% global unemployment rate in 2026, implying a global employed population of roughly **3.61 billion** using standard labor-force arithmetic. citeturn17search10 Applying ILO's independently estimated 25% share of employment in occupations with some GenAI exposure gives a broad ceiling of approximately **900 million AI-exposed workers**. citeturn17search0 This is **not** Humanity AI Circle's realistic serviceable market; it is the global population ceiling for workers whose occupations may be affected by the problem.

| Layer | Defensible current estimate | Interpretation |
|---|---:|---|
| Global employment | ~3.61B derived from ILO 2026 unemployment data | Total labor pool; far too broad. citeturn17search10 |
| Employment in occupations with some GenAI exposure | ~900M directional | Global problem-space ceiling. citeturn17search0 |
| High-income employment exposure | 34% of employment | Shows concentration among digitized/professional work; not a standalone headcount estimate. citeturn17search0 |
| Employees already using AI semi-regularly/regularly | 58% globally in Stanford's survey | Indicates the problem is increasingly optimization/evaluation rather than awareness. citeturn18search0 |
| India workplace AI usage | >80% in Stanford's surveyed employees | Strong launch-market signal, not TAM. citeturn18search0 |

**Data gap:** I found no authoritative primary global dataset that cleanly counts “English-speaking digital knowledge professionals in marketing/product/operations” under one standardized definition. It would be better to disclose this than manufacture a $20B/$50B TAM. Revenue TAM should be calculated only after choosing B2C subscription, enterprise SaaS, research/data licensing, sponsorship, or another commercial model.

### Competitor landscape

| Competitor | Positioning / feature | Evidence model | Repeatability focus | Current traction signal | Business model | Existing moat / gap for HAC | URL |
|---|---|---|---|---|---|---|---|
| **G2** | B2B software marketplace | Verified user reviews, satisfaction and buyer behavior | Low at task level | >3M reviews, 200K+ products/services, 100M+ buyers reached in 2025 ecosystem. citeturn14search9 | Vendor marketing, buyer intent, data solutions. citeturn14search2 | Massive review corpus/distribution; weak real-task baselines and repeated outcomes | [g2.com](https://www.g2.com/) |
| **Product Hunt** | Community-ranked product discovery | Launch votes, discussions, reviews | Low | Global established launch community; official product page shows ~144K followers. citeturn14search16turn14search19 | Advertising / launch ecosystem; detailed economics private | Strong discovery network; evidence is product-centric, not outcome-centric | [producthunt.com](https://www.producthunt.com/) |
| **LMArena** | Community AI model evaluation | Blind human pairwise preference | Strong for preference evaluation, weak for work outcomes | Software/IT leaderboard showed **2.60M votes and 395 models** in Aug. 2026. citeturn16search3 | Business model evolving; evaluation services identified as opportunity. citeturn16search13 | Community-evaluation scale + model access; lacks structured professional outcome context | [lmarena.ai](https://lmarena.ai/) |
| **Artificial Analysis** | Independent AI benchmark company | Repeated standardized model/agent benchmarks | **Very strong** | 500+ models, 100+ providers, 1,000+ endpoints, >1T evaluation tokens. citeturn15search0 | Commercial benchmark/custom evaluation products; Optima adds user-specific workload testing. citeturn15search16 | Evaluation infrastructure; HAC opportunity is human/workplace context and community longitudinal evidence | [artificialanalysis.ai](https://artificialanalysis.ai/) |
| **Workhelix** | Enterprise AI ROI intelligence | Tool usage + role-level AI assessment + power-user benchmarks | Medium | Public enterprise positioning; no comparable public user-volume figure disclosed on cited page. citeturn15search7 | Enterprise B2B/demo-led | Enterprise integration and ROI measurement; not an open cross-company evidence community | [workhelix.com](https://www.workhelix.com/) |
| **GetPrompting** | Practical AI workflows/SOPs | Creator-tested workflow reviews; setup, cost, failures, privacy, review | Medium, mostly single-author | Public workflow/SOP library; offers $49 workflow review and paid packs. citeturn15search1turn15search5turn15search18 | Digital products, consulting/reviews, affiliates | Practical methodology but little independent community replication | [getprompting.com](https://getprompting.com/) |
| **ClawReviews** | Reputation layer for AI software | Human and agent reviews kept separate; moderated provenance | Emerging | Extremely early: major listings such as ChatGPT still showed **0 published reviews** when crawled in Sept. 2026. citeturn16search2turn16search9 | Undisclosed; explicitly no pay-for-rank | Very direct conceptual overlap but currently no evidence volume | [clawreviews.ai](https://www.clawreviews.ai/) |
| **How I AI** | Show-the-work AI workflow media | Guests share screens; workflow steps/prompts/checks extracted | Medium at workflow-documentation level | 106 episodes and **272 published workflows** by Sept. 2026. citeturn20search0turn20search4 | Sponsors + ChatPRD product funnel | Excellent workflow discovery/content; does not aggregate independent repeated outcome measurement | [chatprd.ai/how-i-ai](https://www.chatprd.ai/how-i-ai) |

The competitive map reveals a meaningful opening, but it is narrower than V2 suggests:

```text
DISCOVERY                    EVALUATION                     REAL-WORLD EVIDENCE

Product Hunt                  LMArena
G2                            Artificial Analysis
Directories                   Workhelix
     │                             │
     └─────────── crowded ─────────┘

                                   ↓

               HUMANITY AI CIRCLE OPPORTUNITY

         REAL PERSON + REAL WORK + BASELINE
             + VERSIONED AI WORKFLOW
             + MEASURED OUTCOME
             + HUMAN CORRECTION
             + INDEPENDENT REPLICATION
             + CONTEXTUAL EVIDENCE
```

### KPIs

The North Star should **not** initially be members, posts, session attendance or even number of reviews.

I recommend:

> **North Star: Verified Outcome Replications per week.**

Supporting metrics:

| KPI | Definition |
|---|---|
| **Verified Outcome Replications** | Independent runs attached to an established task protocol and meeting minimum evidence quality |
| **Replication Coverage** | % of active task protocols with at least N independent testers |
| **Repeatability Rate** | % of replicated attempts meeting the predeclared success threshold |
| **Net Outcome Delta** | Difference versus baseline in quality/time/cost, including human review time |
| **Human Correction Burden** | Median minutes/edits needed after AI output |
| **Failure Rate by Type** | Frequency of factual, reasoning, omission, compliance and workflow failures |
| **Evidence Freshness** | % of high-use evidence claims retested against current major model/workflow versions |
| **Decision Utility** | % of users who say the evidence changed or validated an AI workflow decision and later achieved the target outcome |
| **Contributor Retention** | % of testers who contribute another valid run within 30/60 days |
| **Evidence Independence** | Number/share of claims supported by unaffiliated testers rather than vendors/single creators |

For an initial pilot, I would use the following **product-development gates rather than market forecasts**:

```mermaid
timeline
    title Recommended Humanity AI Circle build sequence
    0–3 months : 3 standardized task protocols
               : 100–300 professional testers
               : Manual validation
               : Baseline versus AI measurement
    3–6 months : 1,000+ evidence runs
               : Replication groups
               : Evidence confidence and freshness
               : Public outcome cards
    6–12 months : Profession and skill-level slices
                : Contributor reputation
                : Continuous retesting as models change
                : India launch base plus global cohorts
    12–24 months : Private enterprise cohorts
                 : Evidence API / research reports
                 : Profession-specific benchmarks
                 : Selective expansion into higher-stakes domains
```

These are recommended execution targets, not externally sourced market facts.

### Workflow/media sources worth continuously monitoring

These sources should be treated as **hypothesis generators and workflow-discovery channels**, not automatically as evidence. Their useful workflows can be converted into Humanity AI Circle test protocols and independently replicated.

| Source | Type | Why it matters | URL |
|---|---|---|---|
| **How I AI / Claire Vo** | Podcast + YouTube + workflow library | Guests show their actual work on screen; the site currently exposes hundreds of extracted workflows. citeturn20search0turn20search4 | [How I AI](https://www.chatprd.ai/how-i-ai) |
| **Everyday AI** | Podcast / livestream | Practical business AI workflows and tool use; recent episodes explicitly break down working tool stacks. citeturn20search13 | [Everyday AI](https://www.youreverydayai.com/) |
| **Practical AI** | Podcast | Focuses on practical AI implementation and real-world use rather than only research announcements. citeturn10search22 | [Practical AI](https://changelog.com/practicalai) |
| **Matt Wolfe / FutureTools** | YouTube / media | High-frequency hands-on AI product and workflow discovery; useful source of workflows to test independently. citeturn10search0 | [Matt Wolfe](https://mattwolfe.com/) |
| **Paul J Lipsky** | YouTube | Explicitly positions around testing ChatGPT, Gemini, Claude, NotebookLM and showing nontechnical users what works; site reports 472K subscribers and 25.9M views. citeturn21search10 | [Paul J Lipsky](https://pauljlipsky.com/) |
| **The AI Advantage** | YouTube / community | Workflow and practical-use focus rather than model-news-only coverage. citeturn11search10 | [AI Advantage](https://myaiadvantage.com/) |
| **Jeff Su** | YouTube | Productivity and professional AI workflow demonstrations; useful for identifying business-workflow test candidates. citeturn11search8 | [YouTube](https://www.youtube.com/@JeffSu) |
| **Skill Leap AI** | YouTube / education | High-volume practical tutorials and tool demonstrations; useful as workflow discovery rather than validation. citeturn11search5 | [YouTube](https://www.youtube.com/@SkillLeapAI) |

The key product opportunity is to transform content such as:

> “Here are five amazing Claude workflows”

into:

> “We converted workflow #3 into a controlled task protocol. Forty-six professionals tried it. Here is the measured distribution of outcomes, where it failed, which users benefited and how much human correction remained.”

That is something YouTube cannot easily provide.

## Recommended vision and positioning

**7) Rewritten vision + positioning**

The research suggests keeping the **humanity** of the brand while changing the category you are trying to own.

### Recommended vision

> **Create a world where people can know, with trustworthy real-world evidence, how AI can help them accomplish real work—and where human judgment still matters.**

### Recommended category

> **Real-World AI Evidence Network**

or, more explicitly internally:

> **Human + AI Workflow Evidence Network**

### Recommended public tagline

> # **Real people. Real work. Repeatable AI outcomes.**

I prefer this over changing the entire brand hook because it preserves the strongest part of:

> “Real users. Real tasks. Real AI outcomes.” fileciteturn0file0

while introducing the strategically missing concept: **repeatability**.

### Emotional brand line

Keep V2's existing:

> **AI is moving fast. Humans need to move together.** fileciteturn0file0

It is a strong emotional/community line. It simply should not be the strategic moat.

### Functional positioning

> **Know what actually works with AI—for your work, your context and your level of expertise.**

### Internal definition

> **Humanity AI Circle is a community-powered, versioned evidence network that measures how human + AI workflows perform on real professional tasks. It records the baseline, person and context, workflow and model version, measured outcome, human correction, failure modes and independent replications so people can understand not merely what AI can do, but what works reliably, for whom, under what conditions.**

That definition is aligned with the strongest finding across the research: measured effects are heterogeneous and can be positive, negative, unreliable and rapidly changing. citeturn19search2turn19search15turn22search5turn22search0

### The strategic architecture

Do **not** think of the business as:

```text
COMMUNITY
      ↓
CONTENT
      ↓
REVIEWS
      ↓
MORE MEMBERS
```

Think:

```text
REAL PROFESSIONAL PROBLEM
           ↓
STANDARDIZED TASK
           ↓
HUMAN + AI EXPERIMENT
           ↓
MEASURED OUTCOME
           ↓
VALIDATION
           ↓
INDEPENDENT REPLICATION
           ↓
EVIDENCE CLAIM
           ↓
EVIDENCE GRAPH
           ↓
BETTER DECISION
           ↓
MORE USERS REPLICATE
           ↓
BETTER EVIDENCE
```

The **community is the engine**.

The **evidence product is the value**.

The **evidence graph is the compounding asset**.

The **trust/reputation layer is the moat around the asset**.

### Long-term answer to “what can Humanity AI Circle become?”

Not:

> the largest AI community.

Not:

> the largest AI-tool directory.

Not:

> the biggest collection of AI reviews.

The more ambitious and differentiated goal is:

> **The world's trusted evidence layer for how humans and AI actually work together.**

That can eventually answer questions far more valuable than “Which chatbot is best?”:

```text
For a first-time marketing manager,
producing a source-backed competitive brief,
with sensitive data excluded,
under a 60-minute deadline:

Which workflow works most reliably?

How much time does it really save?

What quality changes?

What model/version was tested?

What commonly fails?

How much human correction is required?

Do beginners and experts get the same result?

Has the result been independently repeated?

When was it last tested?
```

No generic leaderboard answers that question today. Artificial Analysis is moving toward task-specific benchmarking, LMArena has demonstrated scalable crowd evaluation, Workhelix addresses enterprise ROI, and emerging review players are becoming workflow-aware; the remaining opportunity is to connect **professional human context + baseline + actual outcome + repeated validation + longitudinal evidence**. citeturn15search16turn16search3turn15search7turn15search1

## Ready-to-paste V3 additions

**8) Recommended additions to the Humanity AI Circle framework**

The following is the section I would insert into V3. It operationalizes the central lessons from the task-specific productivity experiments, repeatability benchmarks, ROI gap and competitive research above. citeturn19search2turn22search5turn15search15turn18search4

```markdown
## V3 Strategic Evolution

Humanity AI Circle will evolve from a broad AI community concept into a
community-powered real-world AI evidence network.

The community remains essential, but community activity is not the final
product.

The core product is trustworthy evidence about how humans and AI work
together on real tasks.

### Our Category

Real-World AI Evidence Network

### Our Vision

Create a world where people can know, with trustworthy real-world evidence,
how AI can help them accomplish real work — and where human judgment still
matters.

### Brand Hook

AI is moving fast. Humans need to move together.

### Evidence Hook

Real people. Real work. Repeatable AI outcomes.

### Functional Promise

Know what actually works with AI — for your task, your context and your
level of expertise.

### Core Strategic Principle

An AI success story is not evidence until we understand:

- what task was attempted,
- what the baseline was,
- who attempted it,
- under what conditions,
- which workflow was used,
- which tool/model/version was used,
- what outcome occurred,
- how much human correction was required,
- what failed,
- how the result was validated,
- whether other people could repeat it,
- and when the result was last tested.

### New Unit of Value

The unit of value is no longer:

"Tool X is good."

It is:

"For Task Y, User Type Z, under Conditions A/B/C,
Workflow X produced Outcome Delta D versus Baseline B,
using Model Version M, across N independent attempts,
with Repeatability R, Human Review H, and Failure Modes F."

### Evidence Maturity Levels

LEVEL 1 — EXPERIENCE

A member says what happened.

LEVEL 2 — DOCUMENTED RUN

The task, workflow, context and result are recorded.

LEVEL 3 — MEASURED RUN

The result includes measurable outcome data and a baseline.

LEVEL 4 — VERIFIED RUN

Another person, expert or deterministic system verifies the evidence.

LEVEL 5 — REPLICATED EVIDENCE

Independent users repeat the same task protocol.

LEVEL 6 — EVIDENCE CLAIM

Results are aggregated into a contextual, versioned claim with
sample size, outcome distribution, confidence and freshness.

### Evidence Data Model

PERSON CONTEXT
- profession
- function
- seniority
- industry
- AI experience
- domain expertise

TASK PROTOCOL
- desired outcome
- exact task
- input type
- task complexity
- success criteria
- quality rubric
- risk level

BASELINE
- current/no-AI workflow
- baseline time
- baseline cost
- baseline quality

AI WORKFLOW
- workflow steps
- human/AI handoffs
- prompts/instructions where shareable
- tool
- model
- model/version
- plan/tier
- test date

OUTCOME
- completion
- quality
- accuracy
- total time
- total cost
- outcome delta versus baseline

HUMAN INTERVENTION
- review required
- correction time
- edits
- judgment required
- escalation required

FAILURE
- hallucination
- factual error
- reasoning error
- omission
- source failure
- formatting failure
- workflow failure
- privacy/security issue
- other

VALIDATION
- self validated
- peer validated
- domain expert validated
- deterministic test
- objective ground truth

REPLICATION
- protocol ID
- independent tester
- run number
- repeat success/failure

PROVENANCE
- evidence artifact
- contributor identity level
- affiliation
- incentive/sponsorship disclosure

PRIVACY
- user consent
- visibility
- data sensitivity
- retention permission

EVIDENCE CLAIM
- number of runs
- number of independent contributors
- success distribution
- median/mean outcome delta
- failure distribution
- evidence-confidence level
- model/version coverage
- last-tested date
- freshness status

### Evidence Graph

PERSON
  ↓
CONTEXT
  ↓
TASK PROTOCOL
  ↓
BASELINE
  ↘
    OUTCOME DELTA
  ↗
AI WORKFLOW
  ↓
MODEL + VERSION
  ↓
HUMAN CORRECTION
  ↓
FAILURES
  ↓
VALIDATION
  ↓
INDEPENDENT REPLICATION
  ↓
EVIDENCE CLAIM
  ↓
EVIDENCE GRAPH
  ↓
BETTER USER DECISION

### Repeatability Principle

One successful run is an example.

Multiple independent runs are evidence.

Repeated outcomes across different users reveal who benefits.

Repeated failures reveal the boundaries of AI capability.

Repeatability therefore becomes a first-class metric of Humanity AI Circle.

### Freshness Principle

AI evidence has a shelf life.

Every evidence record should include:

- tool version,
- model version where available,
- workflow version,
- date tested,
- date replicated,
- and date last verified.

Important evidence should be retested as models and products change.

### Outcome Principle

We do not optimize for AI usage.

We optimize for better human outcomes.

Every experiment should attempt to measure:

OUTCOME WITH AI
minus
OUTCOME WITHOUT AI / CURRENT BASELINE

including the cost of human review and correction.

### Evidence Quality Principle

Self-reported experience is useful but should not be presented as equivalent
to measured evidence.

The product should visibly distinguish:

ANECDOTE
vs
OBSERVED EXPERIENCE
vs
MEASURED RUN
vs
VERIFIED RUN
vs
REPLICATED CLAIM.

### Initial Target Segment

Start with AI-active, English-speaking knowledge professionals whose work
regularly turns research and data into professional deliverables.

Initial functions:

- marketing
- product
- strategy
- business operations

India can serve as an initial recruitment beachhead while the evidence
product remains global.

### Initial Product

Start with Outcome Tests, not a broad social network.

Initial test families:

1. research package → executive decision memo
2. research notes → source-backed presentation
3. structured data → decision-ready analysis

Each test should capture:

- baseline,
- workflow,
- model/version,
- result,
- time,
- quality,
- human correction,
- failure,
- validation,
- replication.

### Product Priority

P0 — Evidence Engine

- task protocol creation
- structured outcome submission
- baseline capture
- workflow/model versioning
- artifact/evidence upload
- human review
- replication
- evidence cards
- evidence freshness

P1 — Trust and Reputation

- contributor identity
- domain expertise
- verified tester status
- validation history
- conflict/incentive disclosure
- evidence quality reputation

P1 — Evidence Discovery

Users should search:

"What works for this task for someone like me?"

rather than:

"What is the highest-rated AI tool?"

P2 — Community Layer

- discussions around evidence
- replication challenges
- expert reviews
- profession-specific sessions
- workflow improvement
- contributor recognition

P3 — Expansion

Only after evidence density exists:

- profession-specific circles
- enterprise/private testing cohorts
- workforce transition research
- AI workflow benchmarks
- evidence APIs
- research reports
- matching/collaboration
- mentorship
- startup/product insight

### What We Will Not Optimize For Initially

- number of AI tools listed
- number of generic posts
- news volume
- prompt-library size
- WhatsApp membership
- vanity MAU
- generic star ratings
- number of subcommunities

### North Star Metric

Verified Outcome Replications per Week

### Supporting Metrics

EVIDENCE DENSITY
How many task protocols have enough independent runs to support a useful claim?

REPEATABILITY RATE
How often does a workflow independently meet the predefined success threshold?

NET OUTCOME DELTA
How much did quality, time or cost improve after human correction is included?

HUMAN CORRECTION BURDEN
How much human intervention remained necessary?

FAILURE VISIBILITY
What percentage of runs expose meaningful failure modes?

DECISION UTILITY
Did the evidence help another member make a better AI/workflow decision?

CONTRIBUTOR RETENTION
Do people return to test and contribute again?

EVIDENCE FRESHNESS
Is the evidence still valid for current models and workflows?

EVIDENCE INDEPENDENCE
How much of a claim is supported by independent rather than affiliated testers?

### Strategic Flywheel

REAL TASK
↓
STRUCTURED TEST
↓
MEASURED OUTCOME
↓
HUMAN VALIDATION
↓
INDEPENDENT REPLICATION
↓
EVIDENCE CLAIM
↓
BETTER DECISION
↓
BETTER OUTCOME
↓
MORE TRUST
↓
MORE CONTRIBUTORS
↓
MORE REPLICATIONS
↓
STRONGER EVIDENCE GRAPH

### Strategic Asset

Our long-term asset is not the community platform itself.

It is a continuously updated, permission-based evidence graph connecting:

people
×
professional context
×
tasks
×
baselines
×
AI workflows
×
models and versions
×
outcomes
×
human corrections
×
failures
×
replications.

### Strategic Moat

Community alone is not the moat.

Content alone is not the moat.

AI-tool reviews alone are not the moat.

The moat is:

STRUCTURED REAL-WORLD OUTCOME DATA
+
INDEPENDENT REPLICATION
+
CONTEXT
+
VERSION HISTORY
+
HUMAN EXPERTISE
+
TRUST / PROVENANCE
+
A CONTRIBUTOR NETWORK THAT CONTINUOUSLY REFRESHES THE EVIDENCE

### Final Positioning

Humanity AI Circle is a community-powered real-world AI evidence network.

Real people test AI on real professional work, measure what actually
happened, document where human judgment was required, and independently
repeat each other's workflows.

The result is a continuously improving answer to one question:

"What actually works with AI for someone like me, trying to accomplish
this real outcome?"

AI is the enabler.

People are the ecosystem.

Evidence is the product.

Repeatability creates trust.

The evidence graph becomes intelligence.
```

The strategic change can ultimately be summarized in one evolution:

```text
V2
PEOPLE-FIRST AI COMMUNITY
        ↓
REAL USERS + REAL TASKS + REAL OUTCOMES

V3
COMMUNITY-POWERED AI EVIDENCE NETWORK
        ↓
REAL PEOPLE
+ REAL WORK
+ BASELINE
+ CONTEXT
+ VERSIONED WORKFLOW
+ MEASURED OUTCOME
+ HUMAN JUDGMENT
+ FAILURES
+ INDEPENDENT REPLICATION
        ↓
TRUSTED EVIDENCE CLAIMS
        ↓
REAL-WORLD AI EVIDENCE GRAPH
```

The decisive insight from the independent research is therefore not merely that **“evidence is scarce.”** It is that AI evidence must be **contextual, measured, versioned and replicated** because real-world performance is demonstrably jagged, user perception can diverge from measured outcomes, and the systems themselves evolve rapidly. citeturn19search15turn22search5turn22search0turn15search15

That leads to the strongest version of the Humanity AI Circle vision:

> **Build the community around real experiments. Turn those experiments into structured evidence. Turn repeated evidence into trust. Turn the resulting evidence graph into the world's clearest understanding of how humans and AI actually work together.**
# Humanity AI Circle V13 — QA

## Strategic QA

- Primary conversion hook restored: **Don't Figure Out AI Alone**.
- AI-transition context retained without forcing the homepage to explain the entire thesis.
- Life-stage entry points added so more visitors can recognize themselves.
- People-to-people connection is visible before evidence methodology.
- Outcome-first, human-control and evidence principles remain intact.
- Weekly 30 remains the recurring community heartbeat.
- Explore architecture separates deeper research, themes, people, evidence, activity and roadmap from the homepage.
- Status language distinguishes live / defined / starting / next / future.
- Minors are not directly promised open-community access; the People page flags safeguarding/consent needs.

## Static QA

- All local HTML, image, JS and CSS references checked.
- All HTML pages parsed.
- No missing local references at build time.
- All pages use `v13.css`.
- Privacy-conscious trace key upgraded to `hac_trace_v13`.
- Server label upgraded to V13.
- Responsive CSS includes desktop, tablet and mobile breakpoints.

## Homepage density

V12 main-content text was approximately 704 words in the inspected build. V13 main-content text is approximately 564 words while preserving the full story through deeper subpages.

## Release note

This QA does not claim live conversion performance. Conversion scores require real traffic or user testing. The build is structured to collect privacy-conscious click/page-view traces when served through `server.js`.

# Humanity AI Circle V13.1 — UX Correction

V13.1 keeps the V13 thesis and visual system but fixes a visitor-flow mistake discovered in review.

## Key corrections
- Homepage secondary hero CTA now opens **How It Works**, not the Explore hub.
- Explore is a true visitor-facing discovery page, not a meta explanation of the website.
- Cross-page journey labels are written as human questions.
- About, Now, Roadmap, Stories and Research remove internal strategy / release-note language.
- No thesis change: **Don't figure out AI alone. People lead. AI helps. Outcome first. Tool second. Brand last.**

Open `index.html` for the homepage.

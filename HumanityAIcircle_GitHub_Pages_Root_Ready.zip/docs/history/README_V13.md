# Humanity AI Circle V13 — Story + Exploration

## What changed from V12

V13 keeps the V12 thesis but changes the website architecture so the homepage remains a conversion-first front door while deeper material is available through exploration channels.

Primary hero:

> **DON'T FIGURE OUT AI ALONE.**

Context:

> We are all living through an AI transition.

Community invitation:

> Bring your question. Bring your idea. Bring what you know.

## New exploration channels

- `explore.html` — connect-the-dots hub
- `themes.html` — jobs, learning, trust, human connection, responsible AI, autonomy
- `people.html` — different life stages and roles
- `now.html` — what is live, defined, starting, and not yet claimed
- `roadmap.html` — done, now, next, future

Existing deeper pages remain:

- `research.html`
- `evidence.html`
- `sessions.html`
- `stories.html`
- `community.html`
- `how-it-works.html`

## Shared story architecture

Major subpages now connect through:

`Transition → My question → People → Practice → Evidence → Progress`

This allows a visitor to enter from any page and understand how that page fits the larger thesis.

## Community channels

Current join destination: WhatsApp

- WhatsApp: https://chat.whatsapp.com/DsqpygjKEgGHp0yXoh8eLu
- YouTube: https://www.youtube.com/@humanityAicircle
- Instagram: https://www.instagram.com/humanityaicircle/
- Email: humanityaicircle@gmail.com

## Local preview

```bash
node server.js
```

Then open `http://localhost:8080`.

The server is optional; the site is static. The server only adds lightweight event logging to `data/community-events.ndjson`.

## Truth rules

The site deliberately avoids fabricated member counts, testimonials, community evidence, event dates, guaranteed matching, or outcome claims. `now.html` separates what is live from what is defined, starting, next, or future.

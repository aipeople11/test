# Humanity AI Circle V13 — Story + Exploration Lock

## Core thesis

Humanity AI Circle is a people-first community helping people move through the AI transition together.

**People lead. AI helps.**

People come to ask, learn, adapt, connect, experiment, build and share. AI is used in service of human outcomes while human judgment, connection, responsibility and control remain central.

## Conversion front door

**DON’T FIGURE OUT AI ALONE.**

Bring your question. Bring your idea. Bring what you know.

## Deeper site story

Transition → My question → People → Practice → Evidence → Progress

The homepage stays conversion-first. Explore opens the deeper channels: Themes, People, Research, Evidence, What’s happening now, Roadmap, Weekly 30 and Stories.

## Growth rule

Do not add a feature simply because an AI community could have it. Add it when it helps people connect, adapt to AI, use it more effectively and responsibly, or turn shared learning into something useful.

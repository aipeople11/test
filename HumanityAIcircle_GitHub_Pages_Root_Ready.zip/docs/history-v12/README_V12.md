# Humanity AI Circle V12 — Thesis Lock / Final Community Vision

## What this build locks

- Global context: **AI is changing how we work, learn and live.**
- Human promise: **Don't figure it out alone.**
- Community invitation: **Bring your question. Bring your idea. Bring what you know.**
- Human/AI belief: **People lead. AI helps.**
- Practical philosophy: **Outcome first. Tool second. Brand last.**
- Responsible-use principle: use AI without giving away human judgment, connection, responsibility or control.
- Community heartbeat: **Weekly 30** every weekend; exact timing announced in the community.
- Evidence: real tasks → tested workflows → structured outcomes → repeated evidence over time.

## Primary pages

- `index.html` — final homepage story
- `why.html` — member relevance / global curiosity paths
- `how-it-works.html` — community loop, articulation, human control
- `community.html` — people-to-people connection and roles
- `evidence.html` — evidence maturity and truth rules
- `research.html` — source-linked transition research
- `sessions.html` — Weekly 30 formats
- `about.html` — thesis and founder/origin story
- `join.html` — join + trust guidance
- `ask.html` — question entry + articulation canvas
- `stories.html` — genuine story framework (no fake testimonials)

Legacy page names are retained as redirects so older links do not break.

## Run locally

The site is fully static and can be opened directly with `index.html`.

For privacy-conscious click traces, run the dependency-free Node server:

```bash
node server.js
```

Then open `http://localhost:8080`. Events are appended to `data/community-events.ndjson`. The trace intentionally records only event name, page path, destination link and timestamp — not message content or personal form data.

## Social links

- WhatsApp: https://chat.whatsapp.com/DsqpygjKEgGHp0yXoh8eLu
- YouTube: https://www.youtube.com/@humanityAicircle
- Instagram: https://www.instagram.com/humanityaicircle/
- Email: humanityaicircle@gmail.com

## Strategy references

`docs/HUMANITY_AI_CIRCLE_MASTER_WEBSITE_PROMPT_V4.md` and `docs/INDEPENDENT_RESEARCH_REPORT.md` are included so the build can be audited against the source strategy.

## Important truth rules

- No fabricated member counts, testimonials, sessions, dates or community evidence.
- Illustrative evidence is labeled as illustrative.
- External research links point to the source.
- The site does not present AI as a substitute for human relationships or professional judgment.
